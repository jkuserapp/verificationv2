<?php
if($_POST['code'] == yourcode-spiecial-characters-may-not-work)
{
include "temporary.html";
} else {
header('HTTP/1.0 403 Forbidden');
}
?>
