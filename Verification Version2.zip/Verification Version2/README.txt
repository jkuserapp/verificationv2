Jak zainstalować?
Skopiuj plik html i php na strone
w pliku html nie usuwaj <!---cokolwiek--->
Poedytuj swoje tesksty ale zachowaj oryginalność

Plik PHP
W pliku php ustawiasz kod
Domyślna wartość 
if($_POST['code'] == yourcode-spiecial-characters-may-not-work)
A zmieniasz to na 
if($_POST['code'] == kochamplacki)
Zmieniacie jeszcze to
TO SĄ PRZYKŁADY!
Z 
include "temporary.html";

Na 
include "plik.html";

temporary.html zmieniasz na jakikolwiek plik na stronie
Ciesz się weryfikacją!